package model;

public class Product {
	private int PRODUCTID;
	private String PRODECTNAME;
	private int MINSELL;
	private int PRICE;
	private int QUENTITY;
	
	public int getPRODUCTID() {
		return PRODUCTID;
	}
	public void setPRODUCTID(int pRODUCTID) {
		PRODUCTID = pRODUCTID;
	}
	public String getPRODECTNAME() {
		return PRODECTNAME;
	}
	public void setPRODECTNAME(String pRODECTNAME) {
		PRODECTNAME = pRODECTNAME;
	}
	public int getMINSELL() {
		return MINSELL;
	}
	public void setMINSELL(int minsell2) {
		MINSELL = minsell2;
	}
	public int getPRICE() {
		return PRICE;
	}
	public void setPRICE(int pRICE) {
		PRICE = pRICE;
	}
	public int getQUENTITY() {
		return QUENTITY;
	}
	public void setQUENTITY(int qUENTITY) {
		QUENTITY = qUENTITY;
	}
	
}
